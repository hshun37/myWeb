package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import vo.IdolGroupVO;
import static db.jdbcUtil.*;
//직접 SQ 구문을 DBMS로 전송하는 클래
public class IdolGroupDAO {
	
	//singletion 패턴
	//클래스 객체가 특정 속성값을 저장하는 용도가 아니고, 연산을 수행하는 메소드만 제공하는 경우
	//객체를 처음에 사용할때만 메모리에 하나만 생성해서 공유하는 패턴
	
	private static IdolGroupDAO instance;
	
	private IdolGroupDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public static IdolGroupDAO getInstance() {
		if(instance == null) {
			//메소드를 처음 호출했으면...
			instance = new IdolGroupDAO();
		}
		return instance;
	}
	
	private Connection con;//자바에서 트랜젝션 작업은 Connection 단위로 이루어짐
	//계좌이체로 처리할려면 계좌이체에 관한 DB 작업을 할 Connection 객체를 하나 생성해서 DAO에 전달해함
	public void setConnection(Connection con) {
		this.con = con;
	}

	public int insertIdolGroup(IdolGroupVO newIdolGroupVO) {
		
		PreparedStatement pstmt = null;
		int insertCount = 0;
		String sql = "INSERT INTO idolGroupVO VALUES(?, ? ,?, ?, ?, ?, ?, ?)";
		try {
			pstmt = con.prepareStatement(sql);
			
			//값 매핑
			pstmt.setString(1, newIdolGroupVO.getName());
			pstmt.setString(2, newIdolGroupVO.getGender());
			pstmt.setInt(3, newIdolGroupVO.getGeneration());
			pstmt.setInt(4, newIdolGroupVO.getYear());
			pstmt.setString(5, newIdolGroupVO.getNation());
			pstmt.setString(6, newIdolGroupVO.getAlbumName());
			pstmt.setString(7, newIdolGroupVO.getSongName());
			pstmt.setString(8, newIdolGroupVO.getCompany());
			
			insertCount = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		return insertCount;
		
//		Statement stmt = null;
//		int insertCount = 0;
//		String sql = "INSERT INTO idolGroupVO VALUES('" + newIdolGroupVO.getName() + "','"
//				+ newIdolGroupVO.getGender() + "',"
//				+ newIdolGroupVO.getGeneration() + ",'"
//				+ newIdolGroupVO.getYear() + "','"
//				+ newIdolGroupVO.getNation() + "','"
//				+ newIdolGroupVO.getAlbumName() + "','"
//				+ newIdolGroupVO.getSongName() + "','"
//				+ newIdolGroupVO.getCompany() + "')"
//				;
//		try {
//			stmt = con.createStatement();
//			insertCount = stmt.executeUpdate(sql);
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		return insertCount;
	}

	public ArrayList<IdolGroupVO> selectIdolGroupList() {
		
		ResultSet rs = null;
		ArrayList<IdolGroupVO> idolGroupList = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM idolGroupVO";
		try {
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				//반환된 레코드가 하나라도 있으먄...
				idolGroupList = new ArrayList<IdolGroupVO>();
				
				
				do {
					idolGroupList.add(new IdolGroupVO(
							rs.getString("name"),
							rs.getString("gender"), 
							rs.getInt("generation"), 
							rs.getInt("year"), 
							rs.getString("nation"), 
							rs.getString("albumName"), 
							rs.getString("songName"), 
							rs.getString("company")));
				} while (rs.next());
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		return idolGroupList;
		
//		ResultSet rs = null;
//		ArrayList<IdolGroupVO> idolGroupList = null;
//		Statement stmt = null;
//		String sql = "SELECT * FROM idolGroupVO";
//		try {
//			stmt = con.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			if(rs.next()) {
//				//반환된 레코드가 하나라도 있으먄...
//				idolGroupList = new ArrayList<IdolGroupVO>();
//				
//				
//				do {
//					idolGroupList.add(new IdolGroupVO(
//							rs.getString("name"),
//							rs.getString("gender"), 
//							rs.getInt("generation"), 
//							rs.getInt("year"), 
//							rs.getString("nation"), 
//							rs.getString("albumName"), 
//							rs.getString("songName"), 
//							rs.getString("company")));
//				} while (rs.next());
//			}
//			
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		return idolGroupList;
	}

	public IdolGroupVO selectIdolGroupVO(String name) {
		
		IdolGroupVO idolGroupVO = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM idolGroupVO WHERE name = ?";
		try {
			pstmt = con.prepareStatement(sql);
			
			//값 매핑
			pstmt.setString(1, name);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				idolGroupVO = new IdolGroupVO(
							rs.getString("name"),
							rs.getString("gender"), 
							rs.getInt("generation"), 
							rs.getInt("year"), 
							rs.getString("nation"), 
							rs.getString("albumName"), 
							rs.getString("songName"), 
							rs.getString("company"));
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		
		
		return idolGroupVO;
		
//		IdolGroupVO idolGroupVO = null;
//		ResultSet rs = null;
//		Statement stmt = null;
//		String sql = "SELECT * FROM idolGroupVO WHERE name = '" + name + "'";
//		try {
//			stmt = con.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			if(rs.next()) {
//				
//				idolGroupVO = new IdolGroupVO(
//							rs.getString("name"),
//							rs.getString("gender"), 
//							rs.getInt("generation"), 
//							rs.getInt("year"), 
//							rs.getString("nation"), 
//							rs.getString("albumName"), 
//							rs.getString("songName"), 
//							rs.getString("company"));
//			}
//			
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		
//		
//		return idolGroupVO;
	}

	public IdolGroupVO selectOldIdolGroupVO(String name) {
		
		IdolGroupVO idolGroupVO = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM idolGroupVO WHERE name = ?";
		try {
			pstmt = con.prepareStatement(sql);
			
			//값 매핑
			pstmt.setString(1, name);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				idolGroupVO = new IdolGroupVO(
							rs.getString("name"),
							rs.getString("gender"), 
							rs.getInt("generation"), 
							rs.getInt("year"), 
							rs.getString("nation"), 
							rs.getString("albumName"), 
							rs.getString("songName"), 
							rs.getString("company"));
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		
		
		return idolGroupVO;
		
//		IdolGroupVO idolGroupVO = null;
//		ResultSet rs = null;
//		Statement stmt = null;
//		String sql = "SELECT * FROM idolGroupVO WHERE name = '" + name + "'";
//		try {
//			stmt = con.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			if(rs.next()) {
//				
//				idolGroupVO = new IdolGroupVO(
//							rs.getString("name"),
//							rs.getString("gender"), 
//							rs.getInt("generation"), 
//							rs.getInt("year"), 
//							rs.getString("nation"), 
//							rs.getString("albumName"), 
//							rs.getString("songName"), 
//							rs.getString("company"));
//			}
//			
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		
//		
//		return idolGroupVO;
	}

	public int updateIdolGroup(IdolGroupVO newIdolGroupVO) {
		
		PreparedStatement pstmt = null;
		int updateCount = 0;
		String sql = "UPDATE idolGroupVO "
				+ " SET gender = ?," 
				+ "generation = ?,"
				+ "year = ?,"
				+ "nation = ?,"
				+ "albumName = ?,"
				+ "songName = ?,"
				+ "company = ?"
				+ " WHERE name = ?"
				;
		try {
			pstmt = con.prepareStatement(sql);
			
			//값 매핑
			pstmt.setString(1, newIdolGroupVO.getGender());
			pstmt.setInt(2, newIdolGroupVO.getGeneration());
			pstmt.setInt(3, newIdolGroupVO.getYear());
			pstmt.setString(4, newIdolGroupVO.getNation());
			pstmt.setString(5, newIdolGroupVO.getAlbumName());
			pstmt.setString(6, newIdolGroupVO.getSongName());
			pstmt.setString(7, newIdolGroupVO.getCompany());
			pstmt.setString(8, newIdolGroupVO.getName());
			
			updateCount = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		return updateCount;
		
//		Statement stmt = null;
//		int updateCount = 0;
//		String sql = "UPDATE idolGroupVO "
//				+ " SET gender = '" + newIdolGroupVO.getGender() + "'," 
//				+ "generation = "+ newIdolGroupVO.getGeneration() + ","
//				+ "year = '"+ newIdolGroupVO.getYear() + "',"
//				+ "nation = '" + newIdolGroupVO.getNation() + "',"
//				+ "albumName = '"+ newIdolGroupVO.getAlbumName() + "',"
//				+ "songName = '"+ newIdolGroupVO.getSongName() + "',"
//				+ "company = '"+ newIdolGroupVO.getCompany() + "'"
//				+ " WHERE name = '" + newIdolGroupVO.getName() + "'"
//				;
//		try {
//			stmt = con.createStatement();
//			updateCount = stmt.executeUpdate(sql);
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		return updateCount;
	}

	public int deleteIdolGroup(String name) {
		
		PreparedStatement pstmt = null;
		int deleteCount = 0;
		String sql = "DELETE FROM idolGroupVO "
				+ " WHERE name = ?"
				;
		try {
			pstmt = con.prepareStatement(sql);
			//값 매핑
			pstmt.setString(1, name);
			
			deleteCount = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		return deleteCount;
		
//		Statement stmt = null;
//		int deleteCount = 0;
//		String sql = "DELETE FROM idolGroupVO "
//				+ " WHERE name = '" + name + "'"
//				;
//		try {
//			stmt = con.createStatement();
//			deleteCount = stmt.executeUpdate(sql);
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		return deleteCount;
	}

	public IdolGroupVO selectSearchedIdolGroupVO(String name) {
		
		IdolGroupVO idolGroupVO = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM idolGroupVO WHERE name = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				
				idolGroupVO = new IdolGroupVO(
							rs.getString("name"),
							rs.getString("gender"), 
							rs.getInt("generation"), 
							rs.getInt("year"), 
							rs.getString("nation"), 
							rs.getString("albumName"), 
							rs.getString("songName"), 
							rs.getString("company"));
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		
		
		return idolGroupVO;
		
//		IdolGroupVO idolGroupVO = null;
//		ResultSet rs = null;
//		Statement stmt = null;
//		String sql = "SELECT * FROM idolGroupVO WHERE name = '" + name + "'";
//		try {
//			stmt = con.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			if(rs.next()) {
//				
//				idolGroupVO = new IdolGroupVO(
//							rs.getString("name"),
//							rs.getString("gender"), 
//							rs.getInt("generation"), 
//							rs.getInt("year"), 
//							rs.getString("nation"), 
//							rs.getString("albumName"), 
//							rs.getString("songName"), 
//							rs.getString("company"));
//			}
//			
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		
//		
//		return idolGroupVO;
	}

	public ArrayList<IdolGroupVO> selectSearchIdolGroupVOList(String generation) {
		
		ResultSet rs = null;
		ArrayList<IdolGroupVO> idolGroupList = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM idolGroupVO WHERE generation = ?";
		try {
			pstmt = con.prepareStatement(sql);
			
			//값 매핑
			pstmt.setInt(1, Integer.parseInt(generation));
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				//반환된 레코드가 하나라도 있으면...
				idolGroupList = new ArrayList<IdolGroupVO>();
				
				
				do {
					idolGroupList.add(new IdolGroupVO(
							rs.getString("name"),
							rs.getString("gender"), 
							rs.getInt("generation"), 
							rs.getInt("year"), 
							rs.getString("nation"), 
							rs.getString("albumName"), 
							rs.getString("songName"), 
							rs.getString("company")));
				} while (rs.next());
			}
			
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			close(pstmt);
		}
		return idolGroupList;
		
//		ResultSet rs = null;
//		ArrayList<IdolGroupVO> idolGroupList = null;
//		Statement stmt = null;
//		String sql = "SELECT * FROM idolGroupVO WHERE generation = " + generation;
//		try {
//			stmt = con.createStatement();
//			rs = stmt.executeQuery(sql);
//			
//			if(rs.next()) {
//				//반환된 레코드가 하나라도 있으면...
//				idolGroupList = new ArrayList<IdolGroupVO>();
//				
//				
//				do {
//					idolGroupList.add(new IdolGroupVO(
//							rs.getString("name"),
//							rs.getString("gender"), 
//							rs.getInt("generation"), 
//							rs.getInt("year"), 
//							rs.getString("nation"), 
//							rs.getString("albumName"), 
//							rs.getString("songName"), 
//							rs.getString("company")));
//				} while (rs.next());
//			}
//			
//		} catch (SQLException e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//		finally {
//			close(stmt);
//		}
//		return idolGroupList;
	}
}


















