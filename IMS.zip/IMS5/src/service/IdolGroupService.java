package service;

import static db.jdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import dao.IdolGroupDAO;
import ui.IdolGroupUI;
import vo.IdolGroupVO;
//트랜젝션 처리는 Service 단에서 수행하므로
//Connection 관리(생성, 소멸)는 Service 클래스에서 처리함
//자바에서 트랜젝션 Connection 단위로 이루어지기 때문이다.
public class IdolGroupService {
	
	//DAO 사용버전
	public boolean registIdolGroupVO(IdolGroupVO newIdolGroupVO) {
		// TODO Auto-generated method stub
		boolean registSuccess = false;
		Connection con = getConnection();
		
		//SQL 구문을 전송할(실행할) DAO(Data Access Object)객체 생성
		//DAO 클래스 : 일반적으로 테이블 하나당 하나를 생성, JOIN이 사용될 때는 하나의 CRUD 작업당 하나씩 생성
		
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		int insertCount = idolGroupDAO.insertIdolGroup(newIdolGroupVO);
		//삽입된 아이돌 정보 개수가 반환됨
		
		if(insertCount > 0) {
			registSuccess = true;
			commit(con);
		}
		else {
			rollback(con);
		}
		close(con);
		return registSuccess;
	}

	public ArrayList<IdolGroupVO> getIdolGroupList() {
		// TODO Auto-generated method stub
		
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		ArrayList<IdolGroupVO> idolList = idolGroupDAO.selectIdolGroupList();
		close(con);
		return idolList;
	}

	public IdolGroupVO getDetailIdolGroupVO(String name) {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		IdolGroupVO idolGroupVO = 
				idolGroupDAO.selectIdolGroupVO(name);
		close(con);
		return idolGroupVO;
	}

	public IdolGroupVO getOldIdolGroupVO(String name) {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		IdolGroupVO idolGroupVO = 
				idolGroupDAO.selectOldIdolGroupVO(name);
		close(con);
		return idolGroupVO;
	}

	public boolean modifyIdolGroupVO(IdolGroupVO newIdolGroupVO) {
		// TODO Auto-generated method stub
		boolean modifySuccess = false;
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		int updateCount = idolGroupDAO.updateIdolGroup(newIdolGroupVO);
		
		if(updateCount > 0) {
			modifySuccess = true;
			commit(con);
		}
		else {
			rollback(con);
		}
		close(con);
		return modifySuccess;
	}

	public boolean removeIdolGroupVO(String name) {
		// TODO Auto-generated method stub
		boolean removeSuccess = false;
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		int deleteCount = idolGroupDAO.deleteIdolGroup(name);
		
		if(deleteCount > 0) {
			removeSuccess = true;
			commit(con);
		}
		else {
			rollback(con);
		}
		close(con);
		return removeSuccess;
	}

	public IdolGroupVO searchIdolGroupVOByName(String name) {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		IdolGroupVO idolGroupVO = 
				idolGroupDAO.selectSearchedIdolGroupVO(name);
		close(con);
		return idolGroupVO;
	}

	public ArrayList<IdolGroupVO> searchIdolGroupVOListByGeneration(String generation) {
		// TODO Auto-generated method stub
		Connection con = getConnection();
		IdolGroupDAO idolGroupDAO = IdolGroupDAO.getInstance();
		idolGroupDAO.setConnection(con);
		
		ArrayList<IdolGroupVO> searchIdolGroupVOList = 
				idolGroupDAO.selectSearchIdolGroupVOList(generation);
		close(con);
		return searchIdolGroupVOList;
	}
}







