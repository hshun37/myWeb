package db;
//package datebase;
//
//public class Main {
//
//	public static void main(String[] args) {
//		DBConnection connection = new DBConnection();
//		System.out.println("관리자 여부 : " + connection.isIdolGroupVO("홍성훈"));
//	}
//
//}
