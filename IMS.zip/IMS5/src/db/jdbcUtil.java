package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class jdbcUtil {
	
	private Connection con = null;
	private Statement st = null;
	private ResultSet rs;
	
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/idolGroup?useSSL=false", "root", "nara8740..");
			con.setAutoCommit(false);
			System.out.println("connection success!!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public static void close(Connection con) {
		try {
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Statement stmt) {
		try {
			stmt.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void close(ResultSet rs) {
		try {
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
	}
}
		//트랙젝션 관련 처리...
		public static void commit(Connection con) {
			try {
				con.commit();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		public static void rollback(Connection con) {
			try {
				con.rollback();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
	
/*	
	public DBConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/idolGroup", "root", "nara8740..");
			st = con.createStatement();
			System.out.println("connection success!!!");
		} catch (Exception e) {
			System.out.println("데이터 베이스 연결 오류 : " + e.getMessage());;
		}
	}
	 
	public boolean isIdolGroupVO(String name) {
		try {
			String SQL = "SELECT * FROM idolGroupVO WHERE name = '" + name + "'";
			rs = st.executeQuery(SQL);
			if(rs.next() ) {
				return true;
			}
		} catch (Exception e) {
			System.out.println("데이터베이스 검색 오류 : " + e.getMessage());
		}
		return false;
	}
*/	


