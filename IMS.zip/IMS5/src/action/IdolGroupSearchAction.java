package action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import service.IdolGroupService;
import service.SearchService;
import util.ConsoleUtil;
import vo.IdolGroupVO;
import vo.SearchVO;

public class IdolGroupSearchAction implements Action {

	@Override
	public void execute(Scanner scanner) throws Exception {
		// TODO Auto-generated method stub
		ConsoleUtil consoleUtil = new ConsoleUtil();
		SearchVO searchVO = consoleUtil.getSearchVO(scanner);
		
		IdolGroupService idolGroupService
		= new IdolGroupService();
		
		if(searchVO.getSearchCondition().contentEquals("이름")) {
			IdolGroupVO idolGroupVO = 
					idolGroupService.searchIdolGroupVOByName(searchVO.getSearchValue());
			consoleUtil.printSearchIdolGroupVO(idolGroupVO);
		}
		else {
			ArrayList<IdolGroupVO> idolGroupVOList = 
					idolGroupService.searchIdolGroupVOListByGeneration(searchVO.getSearchValue());
			consoleUtil.printSearchIdolGroupVOArray(idolGroupVOList);
		}
		
		
	}

}



