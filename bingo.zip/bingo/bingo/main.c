#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
void gotoxy(int x, int y); //커서 좌표 조절
void Random_Number_(int a[]); //난수를 생성하고 중복된 숫자는 바꾸는 함수
void Change_(int a[], int input); //숫자를 입력받으면 배열의 값을 바꾸는 함수
int Check_(int a[]); //빙고가 몇 줄 생성되었는지 검사하는 함수
int main(void)
{
int user[25], computer[25], i, input = 1, user_line = 0, computer_line = 0;
srand(time(NULL));
while (input)
{
Random_Number_(user); //난수 생성
Random_Number_(computer);
while (1)
{
system("cls");
printf("           빙고\n\n");
printf(" ┌───────────┐\n");
for (i = 0; i <= 24; i++)
{
if (i % 5 != 0 || i == 0)
printf("%5d", user[i]);
else
printf("\n\n%5d", user[i]);
}
for (i = 4; i <= 13; i++)
{
gotoxy(2, i);
printf("│");
gotoxy(26, i);
printf("│");
}
printf("\n └───────────┘\n숫자를 입력하세요\n0을 입력하면 종 료합니다.");
printf("\n\n"); // 빙고판 생성
scanf("%d", &input);
if (input == 0) // 0을 입력받을시 프로그램이 종료하게 된다.
break;
Change_(user, input);
Change_(computer, input);
user_line = Check_(user);
computer_line = Check_(computer);
if (user_line >= 5 && computer_line < 5)//승리 조건에 만족 하였는지 검사한 다.
{
printf("플레이어 승리!\n컴퓨터의 판\n");
for (i = 0; i <= 24; i++)
{
if (i % 5 != 0 || i == 0)
{
printf("%5d", computer[i]);
}
else
printf("\n\n%5d", computer[i]);
}
printf("\n0입력하면 종료\n0을 제외한 숫자를 입력하면 재시작\n");
scanf("%d", &input);
break;
}
else if (computer_line >= 5 && user_line < 5)
{
printf("컴퓨터 승리!\n컴퓨터의 판\n");
for (i = 0; i <= 24; i++)
{
if (i % 5 != 0 || i == 0)
{
gotoxy(30, 3);
printf("%5d", computer[i]);
}
else
printf("\n\n%5d", computer[i]);
}
printf("\n0입력하면 종료\n0을 제외한 숫자를 입력하면 재시작\n");
scanf("%d", &input);
break;
}
else if (computer_line == 5 && user_line == 5)
{
printf("무승부\n컴퓨터의 판\n");
for (i = 0; i <= 24; i++)
{
if (i % 5 != 0 || i == 0)
printf("%5d", computer[i]);
else
printf("\n\n%5d", computer[i]);
}
printf("\n0입력하면 종료\n0을 제외한 숫자를 입력하면 재시작\n");
scanf("%d", &input);
break;
}
else
{
user_line = 0;
computer_line = 0;
}
}
}
return 0;
}
void gotoxy(int x, int y)
{
COORD Pos = { x - 1, y - 1 };
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
}
void Random_Number_(int a[])
{
int i, num[25], rand_num;
for (i = 0; i <= 24; i++)
num[i] = i + 1;
for (i = 0; i <= 24; i++)
{
rand_num = rand() % 25;
if (num[rand_num] != 0)
{
a[i] = num[rand_num];
num[rand_num] = 0;
}
else
i--;
}
}
void Change_(int a[], int input)
{
int i;
for (i = 0; i <= 24; i++)
{
if (a[i] == input)
{
a[i] = 0;
i = i + 25;
}
}
}
int Check_(int a[])
{
int i;
int bingo = 0;
for (i = 0; i <= 24; i = i + 5)//가로줄 검사
{
if (a[i] == 0 && a[i + 1] == 0 && a[i + 2] == 0 && a[i + 3] == 0 && a[i + 4] == 0)
bingo++;
}
for (i = 0; i <= 4; i++)//세로줄 검사
{
if (a[i] == 0 && a[i + 5] == 0 && a[i + 10] == 0 && a[i + 15] == 0 && a[i + 20] == 0)
bingo++;
}
if (a[0] == 0 && a[6] == 0 && a[12] == 0 && a[18] == 0 && a[24] == 0)// 대각선줄 검사
bingo++;
if (a[4] == 0 && a[8] == 0 && a[12] == 0 && a[16] == 0 && a[20] == 0)
bingo++;
return bingo;
}
