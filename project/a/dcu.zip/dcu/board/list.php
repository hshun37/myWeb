<!DOCTYPE html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <lint rel="stylesheet" href="../css/common.css">
  <!--레이아웃 관련 css-->
  <link rel="stylesheet" href="../css/layout.css">
  <title>Document</title>
 </head>
 <body>
  
  <div id="wrap">
  <?php
	include "../inc/header.html";
  ?>

  <!--게시판 목록-->
  <div><a href="write.php">글쓰기</a>
  <h1>게시판 글 목록</h1>
  	<table>
		<thead>
			<tr>
				<th width="50">번호</th>
				<th width="450">제목</th>
				<th width="100">글쓴이</th>
				<th width="100">날짜</th>
				<th width="50">조회</th>
			</tr>
		</thead>

		<tbody>
			<tr>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>
		</tbody>
	</table>
  </div>

  </div>
 </body>
</html>
