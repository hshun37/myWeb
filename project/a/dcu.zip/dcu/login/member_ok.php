<?php
include "../config/db.php";

$user_id = $_POST['user_id'];
$user_pass = $_POST['user_pass'];
$user_name = $_POST['user_name'];
$user_phone = $_POST['user_phone'];
$user_email = $_POST['user_email'];
$user_post = $_POST['user_post'];
$user_address1 = $_POST['user_address1'];
$user_address2 = $_POST['user_address2'];

?>





