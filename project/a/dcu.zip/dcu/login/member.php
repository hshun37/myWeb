<!DOCTYPE html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Document</title>
  <!--초기화 css-->
  <link rel="stylesheet" href="../css/common.css">
  
  <!--레이아웃 관련 css-->
  <link rel="stylesheet" href="../css/layout.css">
 </head>
 <body>
  <div id="wrap">
	<?php
	include "../inc/header.html";
	?>
	<div class="content">
		<h2>회원가입</h2>
		<div id="section">
			<form method="post" action="member_ok.php" name="frm">
			
			<!--  
			<파일첨부>
			<form method="post" action="member_ok.php" name="frm" enctype="multipart/form-data">
			-->

				<div class="member_wrap">
					<table>
						<tr>
							<td>ID</td>
							<td><input type="text" name="user_id"></td>
						</tr>
						
						<tr>
							<td>password</td>
							<td><input type="password" name="user_pass"></td>
						</tr>

						<tr>
							<td>이름</td>
							<td><input type="text" name="user_name"></td>
						</tr>

						<tr>
							<td>휴대폰</td>
							<td><input type="text" name="user_phone"></td>
						</tr>

						<tr>
							<td>email</td>
							<td><input type="text" name="user_email"></td>
						</tr>

						<tr>
							<td>주소</td>
							<td>
							<input type="text" name="user_post" placeholder="우편번호">
							<input type="text" name="user_address1" placeholder="도로명주소">
							<br>
							<input type="text" name="user_address2" placeholder="나머지주소">
							</td>
						</tr>

						<tr>
							<td colspan="2"><input type="submit" value="회원가입"></td>
						</tr>
					</table>
				</div>
			</form>
		</div>
	</div>
  </div>
 </body>
</html>





