#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int ans[4]={rand()%9+1, rand()%10, rand()%10};
    int player[4];
    int strike = 0;
    int ball = 0;
    int count = 1;

    printf("테스트용 정답 출력 : %d %d %d\n", ans[0], ans[1], ans[2]);
    printf("==============================\n");

    for (;;)
    {
        printf("[%d번째 게임] 숫자 3개 입력 : ", count);
        scanf("%d %d %d",&player[0], &player[1], &player[2]);

        for (int i = 0; i < 3; i++)
        {
            if(ans[i]==player[i])
            strike++;
            
            for(int j = 0; j <3; j++)
            {

                if(ans[i]!=player[i] && ans[i]==player[j])
                ball++;
            
            }
            
        }
        
        count++;

        printf("도전횟수 : %d\t%d ball\t%dstrike\n",count,ball,strike);

        if(strike==3)
        {
            printf("정답\n");
            break;
        }

        strike = 0;
        ball = 0;

    }

    return 0;

}
